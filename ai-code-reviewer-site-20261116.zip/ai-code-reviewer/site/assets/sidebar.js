/* sidebar.js — the permanent lesson tree.
 *
 * One function, called from both pages, so the markup exists once. It reads
 * window.LESSONS and window.Progress and writes nothing else: no lesson content,
 * no storage of its own, no second source of truth for the curriculum.
 *
 * Desktop: a fixed 260px column with its own scroll. Under 900px it becomes a
 * drawer opened by the header button, closed by Escape, the close button, or a
 * click on the scrim, with focus trapped inside while it is open.
 *
 * Parts with no lessons yet are dimmed but readable — this is a reference site,
 * and hiding a planned part teaches the reader nothing.
 */
(function () {
  "use strict";

  var C = window.CONTRACTS;
  var bound = false;      /* drawer listeners are bound once, never per render */
  var collapsed = {};     /* part numbers the reader has closed, remembered */
  var root = null;        /* the nav this module rendered into */

  function lessonsOf(part) {
    var list = Array.isArray(window.LESSONS) ? window.LESSONS : [];
    return list
      .filter(function (lesson) {
        return Number(lesson.part) === Number(part.n);
      })
      .sort(function (a, b) {
        return (Number(a.order) || 0) - (Number(b.order) || 0);
      });
  }

  function el(tag, className, text) {
    var node = document.createElement(tag);
    if (className) {
      node.className = className;
    }
    if (text !== undefined && text !== null) {
      node.textContent = String(text);
    }
    return node;
  }

  function counts(part) {
    var lessons = lessonsOf(part);
    var done = 0;
    lessons.forEach(function (lesson) {
      if (window.Progress.isDone(lesson.id)) {
        done += 1;
      }
    });
    return { done: done, total: lessons.length };
  }

  /* ---------------------------------------------------------------- drawer */

  function isNarrow() {
    return window.matchMedia && window.matchMedia("(max-width: 900px)").matches;
  }

  var drawerOpen = false; /* what this module last applied, not what CSS thinks */

  function setDrawer(rootNode, open, fromRender) {
    var toggle = document.getElementById("sidebar-toggle");
    if (!rootNode) {
      return;
    }
    var changed = open !== drawerOpen;
    drawerOpen = open;
    document.body.classList.toggle("sidebar-open", open);
    if (toggle) {
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
    }
    var narrow = isNarrow();
    /* A drawer that is off-screen must not be reachable by Tab or by a screen
     * reader, and `inert` is what actually enforces that. */
    if (narrow) {
      rootNode.setAttribute("aria-hidden", open ? "false" : "true");
    } else {
      rootNode.removeAttribute("aria-hidden");
    }
    if ("inert" in rootNode) {
      rootNode.inert = narrow && !open;
    }
    /* Everything behind the drawer goes inert, not just the lesson body: the
     * header's own buttons must not be reachable through the scrim. The drawer's
     * close button and Escape are the ways out. */
    [".page", ".site-header", ".site-footer"].forEach(function (selector) {
      var node = document.querySelector(selector);
      if (node && "inert" in node) {
        node.inert = narrow && open;
      }
    });
    if (open && changed) {
      var first = rootNode.querySelector("a, button");
      if (first) {
        first.focus();
      }
    } else if (!open && changed && !fromRender && toggle) {
      /* Only when the drawer was actually open: a re-render must not steal focus
       * from whatever the reader was doing. */
      toggle.focus();
    }
  }

  function bindDrawer(rootNode) {
    var toggle = document.getElementById("sidebar-toggle");
    var scrim = document.querySelector(".sidebar-scrim");
    if (!toggle || bound) {
      return;
    }
    bound = true;

    toggle.addEventListener("click", function () {
      setDrawer(root, !document.body.classList.contains("sidebar-open"));
    });

    /* The close button is re-created on every render, so it is delegated from the
     * container instead of bound per instance. */
    rootNode.addEventListener("click", function (event) {
      if (event.target && event.target.closest && event.target.closest(".sidebar-close")) {
        setDrawer(root, false);
      }
    });
    if (scrim) {
      scrim.addEventListener("click", function () {
        setDrawer(root, false);
      });
    }

    document.addEventListener("keydown", function (event) {
      var open = document.body.classList.contains("sidebar-open");
      if (event.key === "Escape" && open) {
        event.preventDefault();
        setDrawer(root, false);
        return;
      }
      /* Focus trap: while the drawer is open, Tab stays inside it. */
      if (event.key === "Tab" && open && isNarrow()) {
        var all = root.querySelectorAll("a[href], button:not([disabled])");
        var focusable = [];
        for (var index = 0; index < all.length; index += 1) {
          /* A link inside a collapsed part is in the DOM but not on screen. */
          if (all[index].offsetParent !== null) {
            focusable.push(all[index]);
          }
        }
        if (!focusable.length) {
          return;
        }
        var first = focusable[0];
        var last = focusable[focusable.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      }
    });

    setDrawer(root, false, true);
    /* Recompute on every resize: the wide->narrow direction used to leave the
     * off-screen drawer exposed to the accessibility tree. */
    window.addEventListener("resize", function () {
      setDrawer(root, isNarrow() && drawerOpen, true);
    });
  }

  /* ---------------------------------------------------------------- render */

  function render(container, currentId) {
    if (!container) {
      return;
    }
    container.innerHTML = "";
    container.className = "sidebar";
    container.setAttribute("aria-label", "All lessons");

    var head = el("div", "sidebar-head");
    head.appendChild(el("p", "sidebar-title", "All lessons"));
    var close = el("button", "sidebar-close", "✕");
    close.type = "button";
    close.setAttribute("aria-label", "Close the lesson list");
    head.appendChild(close);
    container.appendChild(head);

    var scroller = el("div", "sidebar-scroll");
    var current = String(currentId || "");

    /* Resolve the current part BEFORE the render loop. Computing it inside the
     * loop meant every part before the current one saw null and expanded, so a
     * Part 10 lesson opened 11 of 13 groups and the reader never saw Part 10. */
    var currentPart = null;
    C.PARTS.forEach(function (part) {
      var found = lessonsOf(part).some(function (lesson) {
        return String(lesson.id) === current;
      });
      if (found && currentPart === null) {
        currentPart = part.n;
      }
    });

    C.PARTS.forEach(function (part) {
      var lessons = lessonsOf(part);
      var tally = counts(part);
      var isCurrent = lessons.some(function (lesson) {
        return String(lesson.id) === current;
      });
      if (isCurrent) {
        currentPart = part.n;
      }

      var group = el("section", "side-part" + (lessons.length ? "" : " is-pending"));
      group.setAttribute("data-part", String(part.n));

      var toggle = el("button", "side-toggle");
      toggle.type = "button";
      /* Three rules, in order. A part the reader explicitly closed stays
       * closed. The part being read opens, so aria-current is visible. With no
       * lesson selected — index.html, tryit.html — every part with lessons
       * opens, because a permanent topic list is what that page is for. */
      var openByDefault;
      if (collapsed[part.n] === false) {
        openByDefault = false;
      } else if (currentPart !== null) {
        openByDefault = String(part.n) === String(currentPart);
      } else {
        openByDefault = lessons.length > 0;
      }
      toggle.setAttribute("aria-expanded", openByDefault ? "true" : "false");
      toggle.appendChild(el("span", "side-part-label", "Part " + part.n + " · " + part.title));
      /* Both numbers are real: done/written, with the planned total named
       * separately so a part that is half written cannot look half done. */
      var countLabel = lessons.length
        ? tally.done + "/" + tally.total
        : "0/" + part.lessons + " planned";
      toggle.appendChild(el("span", "side-part-count", countLabel));
      group.appendChild(toggle);

      var body = el("div", "side-body");
      body.hidden = !openByDefault;

      if (lessons.length) {
        var list = el("ul", "side-lessons");
        lessons.forEach(function (lesson) {
          var item = el("li");
          var link = el("a", "side-lesson", lesson.title);
          link.href = "lesson.html?id=" + encodeURIComponent(lesson.id);
          if (String(lesson.id) === current) {
            link.className += " is-current";
            link.setAttribute("aria-current", "page");
          }
          if (window.Progress.isDone(lesson.id)) {
            link.appendChild(el("span", "side-tick", "✓"));
            link.setAttribute("title", lesson.title + " — done");
          }
          item.appendChild(link);
          list.appendChild(item);
        });
        body.appendChild(list);
      } else {
        body.appendChild(el("p", "side-empty", "Not written yet — " + part.lessons + " lessons planned."));
      }
      group.appendChild(body);

      toggle.setAttribute("aria-controls", "side-body-" + part.n);
      body.id = "side-body-" + part.n;

      toggle.addEventListener("click", function () {
        var open = toggle.getAttribute("aria-expanded") === "true";
        toggle.setAttribute("aria-expanded", open ? "false" : "true");
        body.hidden = open;
        /* Store the state we are moving TO. Storing `open` recorded the previous
         * state, so the next render inverted every part the reader had touched. */
        collapsed[part.n] = open; /* store the state we move to */
      });

      scroller.appendChild(group);
    });

    container.appendChild(scroller);

    /* No part opens itself. Every part starts closed and the reader's click is
     * the only thing that opens one; the active lesson is still marked inside. */
    root = container;
    bindDrawer(container);
    if (bound) {
      setDrawer(container, drawerOpen, true);
    }
  }

  window.Sidebar = {
    render: render
  };
})();

/* Keep the reader's place: after a render, centre the active link in the scroller
 * so a long list does not open at Part 0 while the lesson is Part 10. */
(function () {
  function centre() {
    var sc = document.querySelector(".sidebar-scroll");
    var active = sc && sc.querySelector('[aria-current="page"]');
    if (sc && active && sc.clientHeight) {
      sc.scrollTop = Math.max(0, active.offsetTop - sc.clientHeight / 2);
    }
  }
  if (typeof document !== "undefined") {
    document.addEventListener("DOMContentLoaded", function () { setTimeout(centre, 120); });
  }
})();
